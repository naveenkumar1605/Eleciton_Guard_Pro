import tkinter as tk
from tkinter import PhotoImage
import tkinter as tk
from tkinter import *
import cv2
import csv
import os
import numpy as np
from PIL import Image, ImageTk
import pandas as pd
import datetime
from time import sleep
import face_recognition
import serial

import winsound 
freq = 10000
dur = 20000
			



ser = serial.Serial("COM5", baudrate=9600, timeout=0.5)
ser.flushInput()

global a
global b
global c
global saravana_count
global abinaya_count
global meenakshi_count
global sanjushree_count
global leena_count
global praveen_count
global sanjay_count
global veemikha_count
global raja_count
global vishnu_count
global eshu_count

global window1
global window2
global window3
global dmk_count
global admk_count
global tvk_count
global ntk_count
global bjp_count
global congress_count
a=0
b=0
c=0
saravana_count=0
abinaya_count=0
meenakshi_count=0
sanjushree_count=0
leena_count=0
praveen_count=0
sanjay_count=0
veemikha_count=0
raja_count=0
vishnu_count=0
eshu_count=0
dmk_count=0
admk_count=0
tvk_count=0
ntk_count=0
bjp_count=0
congress_count=0

def fake_vote():
    global window6
    global window
##    window.withdraw()
    window.destroy()
    window6= tk.Tk()
    print("Fake vote detected")
    window6.title("Fake Voter page")
    window6.geometry('1280x720')
    window6.configure(background='skyblue')
    message6 = tk.Label(window6, text="UNAUTHENTICATION VOTER", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message6.place(x=80, y=100)
##    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
##                   height=3, font=('times', 30, ' bold '))

##    message3.place(x=80, y=300)
    button9 = tk.Button(window6, text="Back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button9.place(x=500, y=500)
    window6.mainloop()
def result():
    global dmk_count
    global admk_count
    global tvk_count
    global ntk_count
    global bjp_count
    global congress_count
    global window4
##    window4.withdraw()
    window4.destroy()
    dmk_result=f"DMK RESULT = {dmk_count}"
    admk_result=f"ADMK RESULT =  {admk_count}"
    tvk_result=f"TVK RESULT = {tvk_count}"
    ntk_result=f"NTK RESULT = {ntk_count}"
    bjp_result=f"BJP RESULT = {bjp_count}"
    congress_result=f"CONGRESS RESULT = {congress_count}"
    
    window5= tk.Tk()
    print("aaaa")
    window5.title("result page")
    window5.geometry('1280x720')
    window5.configure(background='cyan')
    message5 = tk.Label(window5, text="VOTING RESULT", bg="pink", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message5.place(x=80, y=100)

    message6 = tk.Label(window5, text=dmk_result, bg="darkslategrey", fg="white", width=20,
                   height=2, font=('times', 30, ' bold '))

    message6.place(x=70, y=300)

    message7 = tk.Label(window5, text=admk_result, bg="darkslategrey", fg="white", width=20,
                   height=2, font=('times', 30, ' bold '))

    message7.place(x=70, y=400)

    message8 = tk.Label(window5, text=tvk_result, bg="darkslategrey", fg="white", width=20,
                   height=2, font=('times', 30, ' bold '))

    message8.place(x=70, y=500)

    message9 = tk.Label(window5, text=ntk_result, bg="darkslategrey", fg="white", width=20,
                   height=2, font=('times', 30, ' bold '))

    message9.place(x=600, y=300)

    message10 = tk.Label(window5, text=bjp_result, bg="darkslategrey", fg="white", width=20,
                   height=2, font=('times', 30, ' bold '))

    message10.place(x=600, y=400)

    message11 = tk.Label(window5, text=congress_result, bg="darkslategrey", fg="white", width=20,
                   height=2, font=('times', 30, ' bold '))

    message11.place(x=600, y=500)

    
##    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
##                   height=3, font=('times', 30, ' bold '))

##    message3.place(x=80, y=300)
    button9 = tk.Button(window5, text="Back",command=start, width=20, height=2,
                   fg="black", bg="pink", font=('times', 15, 'bold'))
    button9.place(x=500, y=600)

    

##    window5.destroy()
    
def admin_login():
    global window
##    window.withdraw()
    window.destroy()
    global window4
    window4= tk.Tk()
    print("aaaa")
    window4.title("Admin login")
    window4.geometry('1280x720')
    window4.configure(background='skyblue')
    message4 = tk.Label(window4, text="WELCOME TO ADMIN", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message4.place(x=80, y=100)
##    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
##                   height=3, font=('times', 30, ' bold '))

##    message3.place(x=80, y=300)
    button8 = tk.Button(window4, text="VIEW",command=result, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button8.place(x=500, y=500)
    window4.mainloop()

def dmk():
    global dmk_count
    
    dmk_count+=1
    print(dmk_count)
    global window3
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOU ARE VOTED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="BACK",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)

def admk():
    global admk_count
    
    admk_count+=1
    print(admk_count)
    global window2
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOU ARE VOTED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)

def tvk():
    global tvk_count
    
    tvk_count+=1
    print(tvk_count)
    global window2
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOU ARE VOTED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)

def ntk():
    global ntk_count
    
    ntk_count+=1
    print(ntk_count)
    global window2
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOU ARE VOTED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)

def bjp():
    global bjp_count
    
    bjp_count+=1
    print(bjp_count)
    global window2
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOU ARE VOTED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)

def congress():
    global congress_count
    
    congress_count+=1
    print(congress_count)
    global window2
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOUR VOTE HAS BEEN REGISTERED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="Back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)
    
def success():
    global window2
##    window2.withdraw()
    window2.destroy()
    window3= tk.Tk()
    print("aaaa")
    window3.title("select party")
    window3.geometry('1280x720')
    window3.configure(background='skyblue')
    message3 = tk.Label(window3, text="YOU ARE VOTED SUCCESSFULLY!", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=100)
    message3 = tk.Label(window3, text="THE BALLOT IS STRONGER THAN THE BULLET", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message3.place(x=80, y=300)
    button7 = tk.Button(window3, text="back",command=start, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button7.place(x=500, y=500)
    
def select():
    global window1
    global window2
##    window1.withdraw()
    window1.destroy()
##    window5.destroy()
    window2= tk.Tk()
    print("aaaa")
    window2.title("select party")
    window2.geometry('1280x720')
    window2.configure(background='skyblue')
    message2 = tk.Label(window2, text="SELECT PARTY", bg="violet", fg="black", width=48,
                   height=3, font=('times', 30, ' bold '))

    message2.place(x=80, y=100)
    button2 = tk.Button(window2, text="DMK",command=dmk, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    
    button2.place(x=300, y=300)
   
    button3 = tk.Button(window2, text="ADMK",command=admk, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button3.place(x=300, y=400)
    

    
    button4 = tk.Button(window2, text="TVK",command=tvk, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button4.place(x=300, y=500)
    button4 = tk.Button(window2, text="NTK",command=ntk, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button4.place(x=600, y=300)
    button5 = tk.Button(window2, text="BJP",command=bjp, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button5.place(x=600, y=400)
    button6 = tk.Button(window2, text="CONGRESS",command=congress, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button6.place(x=600, y=500)
    


    
    

def allow(Aravinth):
    try:
        global window1
        person=Aravinth
        window1= tk.Tk()
        print("aaaa")
        window1.title("voting process")
        window1.geometry('1280x720')
        window1.configure(background='skyblue')
        import pandas as pd
        file_path = 'voter.csv'
        df = pd.read_csv(file_path)
        row_index = person
        single_row = df.iloc[row_index]
        print(single_row)

##        d="You are allowed to vote"
        message1 = tk.Label(window1, text=single_row, bg="violet", fg="black", width=48,
                       height=5, font=('times', 30, ' bold '))

        message1.place(x=80, y=100)
        
        button = tk.Button(window1, text="vote",command=select, width=20, height=2,
                       fg="black", bg="violet", font=('times', 15, 'bold'))
        button.place(x=500, y=400)
        window1.mainloop()
##     window1.close()

    except Exception as e:
        print(e)

    
def clear():
##    window1.destroyWindows()
##    global window1
##    window1.close()
    global f1
    
    def face():
        global f1
        
        from time import sleep
        import winsound
        frequency = 2500
        duration = 3000
        import smtplib
        global a
        global b
        global c
        global saravana_count
        global abinaya_count
        global meenakshi_count
        global sanjushree_count
        global sanjay_count
        global veemikha_count
        global raja_count
        global vishnu_count
        global leena_count
        global praveen_count
        global eshu_count

        #Face Training
        video_capture = cv2.VideoCapture(0)
        Aravinth_image = face_recognition.load_image_file("Image/Aravinth.jpeg")
        Aravinth_face_encoding = face_recognition.face_encodings(Aravinth_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Naveen_image = face_recognition.load_image_file("Image/Naveen.jpeg")
        Naveen_face_encoding = face_recognition.face_encodings(Naveen_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Vikashmaran_image = face_recognition.load_image_file("Image/Vikashmaran.jpeg")
        Vikashmaran_face_encoding = face_recognition.face_encodings(Vikashmaran_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Saravanakumar_image = face_recognition.load_image_file("Image/Saravankumar.png")
        Saravanakumar_face_encoding = face_recognition.face_encodings(Saravanakumar_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Abinaya_image = face_recognition.load_image_file("Image/Abinaya.jpg")
        Abinaya_face_encoding = face_recognition.face_encodings(Abinaya_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Meenakshi_image = face_recognition.load_image_file("Image/Meenakshi.jpg")
        Meenakshi_face_encoding = face_recognition.face_encodings(Meenakshi_image)[0]

        # Load a second sample picture and learn how to recognize it.
        SanjuShree_image = face_recognition.load_image_file("Image/SanjuShree.jpg")
        SanjuShree_face_encoding = face_recognition.face_encodings(SanjuShree_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Leena_image = face_recognition.load_image_file("Image/Leena.jpg")
        Leena_face_encoding = face_recognition.face_encodings(Leena_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Praveen_image = face_recognition.load_image_file("Image/Praveen.jpg")
        Praveen_face_encoding = face_recognition.face_encodings(Praveen_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Sanjay_image = face_recognition.load_image_file("Image/Sanjay.png")
        Sanjay_face_encoding = face_recognition.face_encodings(Sanjay_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Veemikha_image = face_recognition.load_image_file("Image/Veemi.jpg")
        Veemikha_face_encoding = face_recognition.face_encodings(Veemikha_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Raja_image = face_recognition.load_image_file("Image/Raja.png")
        Raja_face_encoding = face_recognition.face_encodings(Raja_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Vishnu_image = face_recognition.load_image_file("Image/Vishnu.jpg")
        Vishnu_face_encoding = face_recognition.face_encodings(Vishnu_image)[0]

        # Load a second sample picture and learn how to recognize it.
        Eshu_image = face_recognition.load_image_file("Image/Eshu.jpg")
        Eshu_face_encoding = face_recognition.face_encodings(Eshu_image)[0]

        

        

        # Create arrays of known face encodings and their names
        known_face_encodings = [

            Aravinth_face_encoding,
            Naveen_face_encoding,
            Vikashmaran_face_encoding,
            Saravanakumar_face_encoding,
            Abinaya_face_encoding,
            Meenakshi_face_encoding,
            SanjuShree_face_encoding,
            Leena_face_encoding,
            Praveen_face_encoding,
            Sanjay_face_encoding,
            Veemikha_face_encoding,
            Raja_face_encoding,
            Vishnu_face_encoding,
            Eshu_face_encoding,
            
        ]
        known_face_names = [

            "Aravinth",
            "Naveen",
            "Vikashmaran",
            "Saravanakumar",
            "Abinaya",
            "Meenakshi",
            "SanjuShree",
            "Leena",
            "Praveen",
            "Sanjay",
            "Veemikha",
            "Raja",
            "Vishnu",
            "Eshu"
        ]

        # Initialize some variables
        face_locations = []
        face_encodings = []
        face_names = []
        process_this_frame = True
        name=""
        while True:
            # Grab a single frame of video
            ret, frame = video_capture.read()

            # Resize frame of video to 1/4 size for faster face recognition processing
            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

            # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
            rgb_small_frame = small_frame[:, :, ::-1]

            # Only process every other frame of video to save time
            if process_this_frame:
                # Find all the faces and face encodings in the current frame of video
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                face_names = []
                for face_encoding in face_encodings:
                    # See if the face is a match for the known face(s)
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                    name = "Unknown"

                    face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        name = known_face_names[best_match_index]

                    face_names.append(name)

            process_this_frame = not process_this_frame


            # Display the results
            for (top, right, bottom, left), name in zip(face_locations, face_names):
                # Scale back up face locations since the frame we detected in was scaled to 1/4 size
                top *= 4
                right *= 4
                bottom *= 4
                left *= 4

                # Draw a box around the face
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

                # Draw a label with a name below the face
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

            # Display the resulting image
            cv2.imshow('Video', frame)
            if(name == "Unknown"):
                print("UNKNOWN PERSON")
    ##            cv2.destroyAllWindows()
    ##            break

            if(f1=='2'):
                if (name == "Aravinth"):
                    if(a==0):
                        print("Welcome Aravinth")
                        a=a+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        Aravinth=0
                        allow(Aravinth)
                    else:
                        print("Fake Vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                    break
                else:
                    print("This not Aravinth. Your unathurised person")
                    break

            if (f1=='1'):
                if(name == "Naveen"):
                    if(b==0):
                        print("Admin Access Granded")
                        Naveen=1
                        
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        admin_login()
                    
                else:
                    print("This not Naveen. Your unathurised person")
                    break

            if (f1=='3'):
                if(name == "Vikashmaran"):
                     if(c==0):
                        print("Welcome Vikashmaran")
                        Vikashmaran=2
                        c=c+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Vikashmaran)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Vikashmaran. Your unathurised person")
                    break

            if (f1=='4'):
                if(name == "Saravanakumar"):
                     if(saravana_count==0):
                        print("Welcome Saravanakumar")
                        Saravanakumar=3
                        saravana_count=saravana_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Saravanakumar)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Saravanakumar. Your unathurised person")
                    break

            if (f1=='5'):
                if(name == "Abinaya"):
                     if(abinaya_count==0):
                        print("Welcome Abinaya")
                        Abinaya=4
                        abinaya_count=abinaya_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Abinaya)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Abinaya. Your unathurised person")
                    break

            if (f1=='6'):
                if(name == "Meenakshi"):
                     if(meenakshi_count==0):
                        print("Welcome Meenakshi")
                        Meenakshi=5
                        meenakshi_count=meenakshi_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Meenakshi)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Meenakshi. Your unathurised person")
                    break

            if (f1=='8'):
                if(name == "SanjuShree"):
                     if(sanjushree_count==0):
                        print("Welcome SanjuShree")
                        SanjuShree=6
                        sanjushree_count=sanjushree_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(SanjuShree)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not SanjuShree. Your unathurised person")
                    break

            if (f1=='9'):
                if(name == "Leena"):
                     if(leena_count==0):
                        print("Welcome Leena")
                        Leena=7
                        leena_count=leena_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Leena)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Leena. Your unathurised person")
                    break

            if (f1=='10'):
                if(name == "Praveen"):
                     if(praveen_count==0):
                        print("Welcome Ponni")
                        Praveen=7
                        praveen_count=praveen_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Praveen)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Ponni. Your unathurised person")
                    break

            if (f1=='11'):
                if(name == "Sanjay"):
                     if(sanjay_count==0):
                        print("Welcome Sanjay")
                        Sanjay=8
                        sanjay_count=sanjay_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Sanjay)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Sanjay. Your unathurised person")
                    break

            if (f1=='12'):
                if(name == "Veemikha"):
                     if(veemikha_count==0):
                        print("Welcome Veemikha")
                        Veemikha=8
                        Veemikha_count=Veemikha_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Veemikha)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Veemikha. Your unathurised person")
                    break

            if (f1=='13'):
                if(name == "Raja"):
                     if(raja_count==0):
                        print("Welcome Rajapandian")
                        Raja=8
                        raja_count=raja_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Raja)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Rajapandian. Your unathurised person")
                    break

            if (f1=='14'):
                if(name == "Vishnu"):
                     if(vishnu_count==0):
                        print("Welcome Vishnu")
                        Vishnu=10
                        vishnu_count=vishnu_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Vishnu)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Vishnu. Your unathurised person")
                    break

            if (f1=='15'):
                if(name == "Eshu"):
                     if(eshu_count==0):
                        print("Welcome Eshu")
                        Eshu=11
                        eshu_count=eshu_count+1
                        sleep(5)
                        cv2.destroyAllWindows()
                        window.withdraw()
                        allow(Eshu)
                     else:
                        print("Fake vote")
                        winsound.Beep(freq, dur)
                        cv2.destroyAllWindows()
                        fake_vote()
                     break
                else:
                    print("This not Eshu. Your unathurised person")
                    break
        
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    def seri():
        global f1
        print("Place Your Finger")
        
        a = ser.readline().decode('ascii').strip()
##        if a:
##        f1 = int(a)
        f1 = a
##            print(f1)
        if f1 == '0':
            print(f1)
            print("Unathurised person")
        if f1 == '1':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '2':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '3':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '4':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '5':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '6':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '8':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '9':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '10':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '11':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '12':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '13':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '14':
            print(f1)
            print("Get Ready your Face")
            face()
        if f1 == '15':
            print(f1)
            print("Get Ready your Face")
            face()

        else:
            seri()

    seri()
            
 
def start():
    
    
    global window
    window = tk.Tk()
    window.title("Voting by face Recognition")
    window.geometry('1280x720')
    window.configure(background="Skyblue")
    

    e="Welcome to Election Guard Pro the Secure Voting System"
    message = tk.Label(window, text=e, bg="violet", fg="black", width=48,
                       height=3, font=('times', 30, ' bold '))

    message.place(x=80, y=100)
    Notification = tk.Label(window, text="Voted successful", bg="Green", fg="white", width=15,
                            height=3, font=('times', 17))
    button = tk.Button(window, text="Go",command=clear, width=20, height=2,
                   fg="black", bg="violet", font=('times', 15, 'bold'))
    button.place(x=500, y=300)
    
    

    ##txt2 = tk.Entry(window, width=20, bg="white",
    ##                fg="black", font=('times', 25))




    window.mainloop()

start()
