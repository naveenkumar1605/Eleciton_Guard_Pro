import tkinter as tk
from tkinter import ttk
from threading import Thread
import datetime
import csv
import pandas as pd
import serial
import face_recognition
import cv2
import numpy as np
from time import sleep

# Global variable to store the recognized name
recognized_name = ""
b = ""
c = 0

def show_next_page():
    # Hide current page
    frame1.pack_forget()
    
    # Show next page
    frame2.pack()

def show_voters_page():
    # Hide current page
    frame2.pack_forget()
    
    # Show voters page
    frame3.pack()
    display_voters()

def show_voter_data():
    global c
    frame4.pack_forget()
    frame4.pack()
    if recognized_name == "Unknown":
        show_voter_data_page("unknown", "20")
    elif recognized_name == "Naveen":
        show_voter_data_page("Naveen", "20")
    elif recognized_name == "Aravinth":
        show_voter_data_page("Aravinth", "20")
    elif recognized_name == "Vikashmaran":
        show_voter_data_page("Vikashmaran", "20")

def show_voter_data_page(name, age):
    global c
    for widget in frame4.winfo_children():
        widget.destroy()
    
    tk.Label(frame4, text="Voter Data", font=("Helvetica", 16, "bold"), fg="blue").pack(pady=20)
    tk.Label(frame4, text=f"Name: {name}", font=("Helvetica", 12)).pack(pady=10)
    tk.Label(frame4, text=f"Age: {age}", font=("Helvetica", 12)).pack(pady=10)
    tk.Button(frame4, text="OK", command=show_voter_data).pack(pady=20)

def show_naveen_data():
    frame5.pack_forget()
    frame5.pack()
    
    tk.Label(frame5, text="Naveen's Voter Data", font=("Helvetica", 16, "bold"), fg="blue").pack(pady=20)
    tk.Label(frame5, text="Name: Naveen", font=("Helvetica", 12)).pack(pady=10)
    tk.Label(frame5, text="Age: 20", font=("Helvetica", 12)).pack(pady=10)
    tk.Label(frame5, text="Voting ID: NV", font=("Helvetica", 12)).pack(pady=10)
    tk.Label(frame5, text="Ward: pudhukottai", font=("Helvetica", 12)).pack(pady=10)
    tk.Button(frame5, text="OK", command=show_voter_data).pack(pady=20)

ser = serial.Serial(port="COM5", baudrate=9600, timeout=0.5)
ser.flushInput()

def fingerprint():
    global b
    print("fingerprint enable")
    while True:
        a = ser.readline().decode('ascii').strip()
        if a:
            b = int(a)
            print(b)
            if b == 0:
                face_recognition_process("unknown")
            elif b == 1:
                face_recognition_process("Naveen")
            elif b == 2:
                face_recognition_process("Aravinth")
            elif b == 3:
                face_recognition_process("Vikashmaran")

def face_recognition_process(person_name):
    global recognized_name

    try:
        # Get a reference to webcam #0 (the default one)
        video_capture = cv2.VideoCapture(0)
        print("camera enable")

        # Load images and create face encodings
        Naveen_image = face_recognition.load_image_file("Naveen.jpeg")
        Naveen_face_encoding = face_recognition.face_encodings(Naveen_image)[0]

        Aravinth_image = face_recognition.load_image_file("Aravinth.jpeg")
        Aravinth_face_encoding = face_recognition.face_encodings(Aravinth_image)[0]

        Vikashmaran_image = face_recognition.load_image_file("Vikashmaran.jpeg")
        Vikashmaran_face_encoding = face_recognition.face_encodings(Vikashmaran_image)[0]

        known_face_encodings = [
            Naveen_face_encoding,
            Aravinth_face_encoding,
            Vikashmaran_face_encoding
        ]
        
        known_face_names = [
            "Naveen",
            "Aravinth",
            "Vikashmaran"
        ]

        face_locations = []
        face_encodings = []
        face_names = []
        process_this_frame = True
        recognized_name = ""

        while True:
            ts = datetime.datetime.now().timestamp()
            age = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
            vote = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')

            ret, frame = video_capture.read()
            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small_frame = small_frame[:, :, ::-1]

            if process_this_frame:
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                face_names = []
                for face_encoding in face_encodings:
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                    recognized_name = "Unknown"
                    
                    face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        recognized_name = known_face_names[best_match_index]

                    face_names.append(recognized_name)

            process_this_frame = not process_this_frame

            for (top, right, bottom, left), name in zip(face_locations, face_names):
                top *= 4
                right *= 4
                bottom *= 4
                left *= 4

                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

            cv2.imshow('Video', frame)
            
            if recognized_name == "Unknown":
                print(f"UNAUTHORIZED PERSON - Date: {age}, Time: {vote}")
                with open('voters.csv', mode='a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([recognized_name, age, 'N/A', 'N/A'])
                sleep(5)
            elif recognized_name:
                print(f"{recognized_name} - age: 20, voting id: {recognized_name[:2]}")
                with open('voters.csv', mode='a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([recognized_name, age, f'VD-{recognized_name[:2]}', 'pudhukottai'])
                
                if recognized_name == "Naveen":
                    show_naveen_data()
                else:
                    sleep(2)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        video_capture.release()
        cv2.destroyAllWindows()

    except FileNotFoundError:
        print("Image file not found")

def display_name():
    global recognized_name
    if recognized_name:
        label_name.config(text=f"Recognized Name: {recognized_name}")
        recognized_name = ""  # Clear the recognized name

def display_voters():
    try:
        voters_df = pd.read_csv('voters.csv')
        
        for widget in frame3.winfo_children():
            widget.destroy()
        
        tk.Label(frame3, text="Voters Data", font=("Helvetica", 16, "bold"), fg="blue").pack(pady=20)
        
        tree = ttk.Treeview(frame3, columns=("Name", "Age", "Voting ID", "Ward"), show='headings')
        tree.heading("Name", text="Name")
        tree.heading("Age", text="Age")
        tree.heading("Voting ID", text="Voting ID")
        tree.heading("Ward", text="Ward")
        
        for index, row in voters_df.iterrows():
            tree.insert("", index, values=(row[0], row[1], row[2], row[3]))
        
        tree.pack(pady=20)
        
    except FileNotFoundError:
        tk.Label(frame3, text="No data available", font=("Helvetica", 12)).pack(pady=20)

root = tk.Tk()
root.title("FACE-RECOGNITION-BASED-VOTING-MANAGEMENT-SYSTEM")
root.geometry('1280x720')
root.configure(background='yellowGreen')

# First Page
frame1 = tk.Frame(root)
tk.Label(frame1, text="FACE-RECOGNITION-BASED-VOTING-MANAGEMENT-SYSTEM",font=("Helvetica", 16, "bold"), fg="blue", width=50, 
         height=2).pack(pady=20) 
tk.Button(frame1, text="Go", command=show_next_page).pack(pady=20)
frame1.pack(pady=100)

# Second Page
frame2 = tk.Frame(root)
tk.Label(frame2, text="FINGER PRINT AND FACE RECOGNITION",font=("Helvetica", 14, "bold"), fg="red", width=50, 
         height=2).pack(pady=20)
tk.Button(frame2, text="start", command=lambda: [Thread(target=fingerprint).start()]).pack(pady=20)
tk.Button(frame2, text="OK", command=show_voters_page).pack(pady=20)
label_name = tk.Label(frame2, text="")
label_name.pack(pady=20)

# Fourth Page
frame4 = tk.Frame(root)
tk.Label(frame4, text="VOTER DATA SHOW",font=("Helvetica", 14, "bold"), fg="red", width=50, 
         height=2).pack(pady=60)
tk.Button(frame4, text="OK", command=show_voter_data).pack(pady=60)
label_name = tk.Label(frame4, text="")
label_name.pack(pady=60)

# Fifth Page
frame5 = tk.Frame(root)

# Third Page
frame3 = tk.Frame(root)

root.mainloop()
