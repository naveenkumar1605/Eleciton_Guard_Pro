import tkinter as tk
from tkinter import ttk
from threading import Thread
import datetime
import csv
import pandas as pd
import serial

# Global variable to store the recognized name
recognized_name = ""
b = ""

def show_next_page():
    # Hide current page
    frame1.pack_forget()
    
    # Show next page
    frame2.pack()

def show_voters_page():
    # Hide current page
    frame2.pack_forget()
    
    # Show voters page
    frame3.pack()
    display_voters()

def show_voter_data_base():
    frame4.pack_forget()
    frame4.pack()
    display_show_voter_data(c)

ser = serial.Serial("COM5", baudrate=9600, timeout=0.5)
ser.flushInput()

def fingerprint():
    global b
    print("fingerprint enable")
    while True:
        a = ser.readline().decode('ascii').strip()
        if a:
            b = int(a)
            print(b)
            if b == 0:
                print("Unathurised person")
            elif b == 1:
                face_recognition("Naveen")
            elif b == 2:
                face_recognition("Aravinth")
            elif b == 3:
                face_recognition("Vikashmaran")

def face_recognition(person_name):
    import face_recognition
    import cv2
    import numpy as np
    from time import sleep

    global recognized_name
##    voters_detail = pd.read_csv('voters_detail.csv')
##    print(voters_detail)

    try:
        # Get a reference to webcam #0 (the default one)
        video_capture = cv2.VideoCapture(0)
        print("camera enable")

        # Load images and create face encodings
        Naveen_image = face_recognition.load_image_file("Naveen.jpeg")
        Naveen_face_encoding = face_recognition.face_encodings(Naveen_image)[0]

        Aravinth_image = face_recognition.load_image_file("Aravinth.jpeg")
        Aravinth_face_encoding = face_recognition.face_encodings(Aravinth_image)[0]

        Vikashmaran_image = face_recognition.load_image_file("Vikashmaran.jpeg")
        Vikashmaran_face_encoding = face_recognition.face_encodings(Vikashmaran_image)[0]

        known_face_encodings = [
            Naveen_face_encoding,
            Aravinth_face_encoding,
            Vikashmaran_face_encoding
        ]
        
        known_face_names = [
            "Naveen",
            "Aravinth",
            "Vikashmaran"
        ]

        face_locations = []
        face_encodings = []
        face_names = []
        process_this_frame = True
        recognized_name = ""

        

        while True:
            ts = datetime.datetime.now().timestamp()
            age = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
            vote = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')

            ret, frame = video_capture.read()
            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small_frame = small_frame[:, :, ::-1]

            if process_this_frame:
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                face_names = []
                for face_encoding in face_encodings:
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                    recognized_name = "Unknown"
                    
                    face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        recognized_name = known_face_names[best_match_index]

                    face_names.append(recognized_name)

            process_this_frame = not process_this_frame

            for (top, right, bottom, left), name in zip(face_locations, face_names):
                top *= 4
                right *= 4
                bottom *= 4
                left *= 4

                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

            cv2.imshow('Video', frame)
            
            if recognized_name == "Unknown":
                print(f"UNAUTHORIZED PERSON - Date: {age}, Time: {vote}")
                with open('voters.csv', mode='a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([recognized_name, age, 'N/A', 'N/A'])
                sleep(5)

            if b==1:
                if recognized_name == "Naveen":
                    print(f"{recognized_name} - age: 20, voting id: {recognized_name[:2]}")
                    with open('voters.csv', mode='a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([recognized_name, age, f'VD-{recognized_name[:2]}', 'pudhukottai'])
                    sleep(2)
                    video_capture.release()
                    cv2.destroyAllWindows()

                else:
                    print("This not Naveen. Your unathurised person")
                    break

            if b==3:
                if recognized_name == "Vikashmaran":
                    print(f"{recognized_name} - age: 20, voting id: {recognized_name[:2]}")
                    with open('voters.csv', mode='a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([recognized_name, age, f'VD-{recognized_name[:2]}', 'pudhukottai'])
                    sleep(2)
                    video_capture.release()
                    cv2.destroyAllWindows()

                else:
                    print("This not Vikashmaran. Your unathurised person")
                    break

            if b==2:
                if recognized_name == "Aravinth":
##                    print(f"{recognized_name} - age: 20, voting id: {recognized_name[:2]}")
                    print("Aravinth")
                    video_capture.release()
                    cv2.destroyAllWindows()
                    with open('voters_detail.csv', mode='r') as file:
                        voter_read = pd.read_csv(file)
                        print(voter_read)
                        
                        print(readed)
                    
                    with open('voters.csv', mode='a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([recognized_name, age, f'VD-{recognized_name[:2]}', 'pudhukottai'])
                    sleep(2)
                    video_capture.release()
                    cv2.destroyAllWindows()

                else:
                    print("This not Aravinth. Your unathurised person")
                    break

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        video_capture.release()
        cv2.destroyAllWindows()

    except FileNotFoundError:
        print("Image file not found")

def display_name():
    global recognized_name
    if recognized_name:
        label_name.config(text=f"Recognized Name: {recognized_name}")
        recognized_name = ""  # Clear the recognized name

def display_voters():
    try:
        voters_df = pd.read_csv('voters.csv')
        
        for widget in frame3.winfo_children():
            widget.destroy()
        
        tk.Label(frame3, text="Voters Data", font=("Helvetica", 16, "bold"), fg="blue").pack(pady=20)
        
        tree = ttk.Treeview(frame3, columns=("Name", "Age", "Voting ID", "Ward"), show='headings')
        tree.heading("Name", text="Name")
        tree.heading("Age", text="Age")
        tree.heading("Voting ID", text="Voting ID")
        tree.heading("Ward", text="Ward")
        
        for index, row in voters_df.iterrows():
            tree.insert("", index, values=(row[0], row[1], row[2], row[3]))
        
        tree.pack(pady=20)
        
    except FileNotFoundError:
        tk.Label(frame3, text="No data available", font=("Helvetica", 12)).pack(pady=20)

root = tk.Tk()
root.title("FACE-RECOGNITION-BASED-VOTING-MANAGEMENT-SYSTEM")
root.geometry('1280x720')
root.configure(background='yellowGreen')

def show_voter_data():
    global c
    print("Show voter data")
    while True:
            if c == 0:
                 print("Unkown")
##                 data=["Name=unknown , Age=20"]
##                 print(data)
            elif c == 1:
                 show_voter_data("Naveen")
            elif c == 2:
                 show_voter_data("Aravinth")
            elif c == 3:
                 show_voter_data("Vikashmaran")
        
    

# First Page
frame1 = tk.Frame(root)
tk.Label(frame1, text="FACE-RECOGNITION-BASED-VOTING-MANAGEMENT-SYSTEM",font=("Helvetica", 16, "bold"), fg="blue", width=50, 
         height=2).pack(pady=20) 
tk.Button(frame1, text="Go", command=show_next_page).pack(pady=20)
frame1.pack(pady=100)

# Second Page
frame2 = tk.Frame(root)
tk.Label(frame2, text="FINGER PRINT AND FACE RECOGNITION",font=("Helvetica", 14, "bold"), fg="red", width=50, 
         height=2).pack(pady=20)
tk.Button(frame2, text="start", command=lambda: [Thread(target=fingerprint).start()]).pack(pady=20)
tk.Button(frame2, text="OK", command=show_voters_page).pack(pady=20)
label_name = tk.Label(frame2, text="")
label_name.pack(pady=20)

#fourth page

frame4 = tk.Frame(root)
tk.Label(frame4, text="VOTER DATA SHOW",font=("Helvetica", 14, "bold"), fg="red", width=50, 
         height=2).pack(pady=20)
##tk.Button(frame2, text="start", command=lambda: [Thread(target=fingerprint).start()]).pack(pady=20)
tk.Button(frame4, text="OK", command=show_voter_data_base).pack(pady=20)
label_name = tk.Label(frame4, text="")
label_name.pack(pady=20)


# Third Page
frame3 = tk.Frame(root)

root.mainloop()




